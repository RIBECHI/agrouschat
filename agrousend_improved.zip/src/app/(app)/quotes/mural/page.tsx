
'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { firestore } from '@/lib/firebase';
import { collection, query, onSnapshot, where, Timestamp, orderBy } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader, ScrollText, User, Calendar, MessageSquare } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { capitalizeName } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';

interface QuoteItem {
    name: string;
    quantity: number;
    unit: string;
}

interface QuoteRequest {
    id: string;
    title: string;
    description: string;
    items: QuoteItem[];
    targetCategories: string[];
    userId: string;
    authorName: string;
    status: 'open' | 'closed';
    createdAt: Timestamp;
}

// Mock user role for now, this should come from the user's profile
const MOCK_SUPPLIER_CATEGORY = 'Insumos';

export default function QuotesMuralPage() {
    const { user } = useAuth();
    const { toast } = useToast();

    const [quotes, setQuotes] = useState<QuoteRequest[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!user) {
            setIsLoading(false);
            return;
        }

        // In a real scenario, you'd get the supplier's category from their profile
        // For now, we mock it. We will also show all open quotes for admins.
        const userCategory = user.role === 'admin' ? null : MOCK_SUPPLIER_CATEGORY;

        let q;
        const quotesCollection = collection(firestore, 'quoteRequests');

        // Refined query: Filter by status and then order. This is more efficient.
        if (userCategory) {
           q = query(quotesCollection, where('status', '==', 'open'), where('targetCategories', 'array-contains', userCategory), orderBy('createdAt', 'desc'));
        } else {
           q = query(quotesCollection, where('status', '==', 'open'), orderBy('createdAt', 'desc'));
        }
        
        setIsLoading(true);
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedQuotes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as QuoteRequest));
            setQuotes(fetchedQuotes);
            setIsLoading(false);
        }, (error) => {
            console.error("Erro ao buscar orçamentos: ", error);
            if((error as any).code === 'failed-precondition') {
                 toast({ variant: "destructive", title: "Erro de Consulta", description: "A consulta requer um índice. Verifique o console para criá-lo." });
            } else {
                 toast({ variant: "destructive", title: "Erro ao carregar o mural." });
            }
            setIsLoading(false);
        });

        return () => unsubscribe();
    }, [user, toast]);
    

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                <ScrollText className="h-8 w-8 text-primary" />
                <h1 className="text-2xl font-bold text-primary">Mural de Cotações</h1>
            </div>
             <CardDescription>
                Veja os pedidos de orçamento abertos por produtores e envie sua proposta.
            </CardDescription>

            {isLoading ? (
                <div className="text-center py-10">
                    <Loader className="mx-auto h-8 w-8 animate-spin text-primary" />
                    <p className="mt-4 text-muted-foreground">Carregando cotações...</p>
                </div>
            ) : quotes.length === 0 ? (
                <Card className="text-center py-10 border-dashed">
                    <CardHeader>
                        <ScrollText className="mx-auto h-12 w-12 text-muted-foreground" />
                        <CardTitle>Nenhum pedido de orçamento encontrado</CardTitle>
                        <CardDescription>Ainda não há pedidos abertos para sua categoria de fornecedor.</CardDescription>
                    </CardHeader>
                </Card>
            ) : (
                <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                    {quotes.map((quote) => (
                        <Card key={quote.id} className="flex flex-col">
                            <CardHeader>
                                <CardTitle>{quote.title}</CardTitle>
                                <div className="text-sm text-muted-foreground space-y-1 pt-1">
                                    <div className="flex items-center gap-2">
                                        <User className="h-4 w-4" />
                                        Enviado por: <Link href={`/profile/${quote.userId}`} className="font-medium hover:underline">{capitalizeName(quote.authorName)}</Link>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Calendar className="h-4 w-4" />
                                        {quote.createdAt ? formatDistanceToNow(quote.createdAt.toDate(), { locale: ptBR, addSuffix: true }) : 'agora mesmo'}
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="flex-grow">
                                <p className="font-medium mb-1">Itens solicitados:</p>
                                <ul className="list-disc list-inside text-sm text-muted-foreground">
                                    {quote.items.map((item, index) => (
                                        <li key={index}>{item.quantity} {item.unit} de {item.name}</li>
                                    ))}
                                </ul>
                                {quote.description && (
                                    <>
                                        <p className="font-medium mt-3 mb-1">Observações:</p>
                                        <p className="text-sm text-muted-foreground whitespace-pre-wrap">{quote.description}</p>
                                    </>
                                )}
                            </CardContent>
                            <CardFooter className="flex-col items-start gap-2">
                                <div>
                                    <p className="text-xs font-semibold text-muted-foreground">CATEGORIAS</p>
                                    <div className="flex flex-wrap gap-2 mt-1">
                                    {quote.targetCategories.map(cat => <Badge key={cat} variant="secondary">{cat}</Badge>)}
                                    </div>
                                </div>
                                <Button className="w-full mt-2" onClick={() => toast({ title: "Em breve!", description: "A resposta via chat será implementada em breve."})}>
                                    <MessageSquare className="mr-2"/>
                                    Enviar Proposta via Chat
                                </Button>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}
