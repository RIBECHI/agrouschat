
'use client';

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { firestore } from '@/lib/firebase';
import { collection, addDoc, query, onSnapshot, serverTimestamp, orderBy, where, doc, deleteDoc, Timestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription, SheetFooter, SheetClose } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader, PlusCircle, Trash2, FileText, MinusCircle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';

const supplierCategories = ['Insumos', 'Peças', 'Serviços', 'Maquinário', 'Outros'];

interface QuoteItem {
    name: string;
    quantity: number;
    unit: string;
}

interface QuoteRequest {
    id: string;
    title: string;
    description: string;
    items: QuoteItem[];
    targetCategories: string[];
    userId: string;
    authorName: string;
    status: 'open' | 'closed';
    createdAt: Timestamp;
}

export default function QuotesPage() {
    const { user } = useAuth();
    const { toast } = useToast();

    const [quotes, setQuotes] = useState<QuoteRequest[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSheetOpen, setIsSheetOpen] = useState(false);
    
    // Form state
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [items, setItems] = useState<QuoteItem[]>([{ name: '', quantity: 1, unit: '' }]);
    const [targetCategories, setTargetCategories] = useState<string[]>([]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const [quoteToDelete, setQuoteToDelete] = useState<string | null>(null);
    const [showDeleteAlert, setShowDeleteAlert] = useState(false);

    useEffect(() => {
        if (!user) {
            setIsLoading(false);
            return;
        }

        const quotesCollection = collection(firestore, 'quoteRequests');
        const q = query(quotesCollection, where('userId', '==', user.uid));
        
        setIsLoading(true);
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedQuotes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as QuoteRequest));
            // Ordena no lado do cliente para evitar índice composto
            fetchedQuotes.sort((a, b) => {
              const dateA = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : 0;
              const dateB = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : 0;
              return dateB - dateA; // Ordem decrescente (mais novo primeiro)
            });
            setQuotes(fetchedQuotes);
            setIsLoading(false);
        }, (error) => {
            console.error("Erro ao buscar orçamentos: ", error);
            toast({ variant: "destructive", title: "Erro ao carregar orçamentos." });
            setIsLoading(false);
        });

        return () => unsubscribe();
    }, [user, toast]);

    const resetForm = useCallback(() => {
        setTitle('');
        setDescription('');
        setItems([{ name: '', quantity: 1, unit: '' }]);
        setTargetCategories([]);
        setIsSubmitting(false);
    }, []);

    const handleItemChange = (index: number, field: keyof QuoteItem, value: string | number) => {
        const newItems = [...items];
        const currentItem = newItems[index];
        if(typeof value === 'string' && field !== 'name' && field !== 'unit') {
            (currentItem as any)[field] = parseFloat(value) || 0;
        } else {
            (currentItem as any)[field] = value;
        }
        setItems(newItems);
    };

    const addItem = () => setItems([...items, { name: '', quantity: 1, unit: '' }]);
    const removeItem = (index: number) => setItems(items.filter((_, i) => i !== index));

    const handleCategoryChange = (category: string) => {
        setTargetCategories(prev => 
            prev.includes(category) 
                ? prev.filter(c => c !== category)
                : [...prev, category]
        );
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user || !title || items.some(item => !item.name || !item.quantity || !item.unit) || targetCategories.length === 0) {
            toast({
                variant: "destructive",
                title: "Campos obrigatórios",
                description: "Título, ao menos um item completo e uma categoria de fornecedor são obrigatórios.",
            });
            return;
        }

        setIsSubmitting(true);
        try {
            const quoteData = {
                userId: user.uid,
                authorName: user.displayName || 'Anônimo',
                title,
                description,
                items,
                targetCategories,
                status: 'open',
                createdAt: serverTimestamp(),
            };

            await addDoc(collection(firestore, 'quoteRequests'), quoteData);

            toast({ title: "Sucesso!", description: "Pedido de orçamento enviado." });
            resetForm();
            setIsSheetOpen(false);
        } catch (error) {
            console.error("Erro ao criar orçamento: ", error);
            toast({ variant: "destructive", title: "Erro ao salvar", description: "Não foi possível criar o pedido." });
        } finally {
            setIsSubmitting(false);
        }
    };

    const openDeleteDialog = (quoteId: string) => {
        setQuoteToDelete(quoteId);
        setShowDeleteAlert(true);
    };

    const handleDeleteQuote = async (quoteId: string | null) => {
        if (!quoteId) return;

        try {
            await deleteDoc(doc(firestore, 'quoteRequests', quoteId));
            toast({ title: "Pedido excluído", description: "O pedido de orçamento foi removido com sucesso." });
        } catch (error) {
            console.error("Erro ao excluir pedido: ", error);
            toast({ variant: "destructive", title: "Erro ao excluir", description: "Não foi possível remover o pedido." });
        } finally {
            setQuoteToDelete(null);
            setShowDeleteAlert(false);
        }
    };

    return (
        <>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-primary flex items-center gap-3"><FileText /> Pedidos de Orçamento</h1>
                <Sheet open={isSheetOpen} onOpenChange={(open) => { if(!open) resetForm(); setIsSheetOpen(open); }}>
                    <SheetTrigger asChild>
                        <Button>
                            <PlusCircle className="mr-2" />
                            Novo Orçamento
                        </Button>
                    </SheetTrigger>
                    <SheetContent className="w-full sm:max-w-lg">
                        <form onSubmit={handleSubmit} className="flex flex-col h-full">
                            <SheetHeader>
                                <SheetTitle>Criar Pedido de Orçamento</SheetTitle>
                                <SheetDescription>
                                    Descreva o que você precisa e envie para fornecedores da plataforma.
                                </SheetDescription>
                            </SheetHeader>
                            <div className="space-y-4 py-6 flex-1 pr-6 overflow-y-auto">
                                <div>
                                    <Label htmlFor="title">Título do Pedido</Label>
                                    <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required placeholder="Ex: Cotação de Insumos para Milho" />
                                </div>
                                <div>
                                    <Label htmlFor="description">Descrição</Label>
                                    <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detalhes adicionais, condições de entrega, etc."/>
                                </div>
                                <div className="space-y-2">
                                    <Label>Itens Necessários</Label>
                                    {items.map((item, index) => (
                                        <div key={index} className="flex gap-2 items-end p-2 border rounded-md">
                                            <div className="flex-grow space-y-1">
                                                <Label htmlFor={`item-name-${index}`} className="text-xs">Nome do Item</Label>
                                                <Input id={`item-name-${index}`} value={item.name} onChange={(e) => handleItemChange(index, 'name', e.target.value)} required placeholder="Ex: Ureia"/>
                                            </div>
                                            <div className="space-y-1 w-20">
                                                <Label htmlFor={`item-qty-${index}`} className="text-xs">Qtd.</Label>
                                                <Input id={`item-qty-${index}`} type="number" value={item.quantity} onChange={(e) => handleItemChange(index, 'quantity', e.target.value)} required placeholder="10"/>
                                            </div>
                                            <div className="space-y-1 w-24">
                                                <Label htmlFor={`item-unit-${index}`} className="text-xs">Unidade</Label>
                                                <Input id={`item-unit-${index}`} value={item.unit} onChange={(e) => handleItemChange(index, 'unit', e.target.value)} required placeholder="ton"/>
                                            </div>
                                            <Button type="button" variant="ghost" size="icon" className="text-destructive h-9 w-9" onClick={() => removeItem(index)} disabled={items.length <= 1}>
                                                <MinusCircle className="h-5 w-5"/>
                                            </Button>
                                        </div>
                                    ))}
                                    <Button type="button" variant="outline" size="sm" onClick={addItem}>Adicionar Item</Button>
                                </div>
                                 <div className="space-y-2">
                                    <Label>Enviar para Fornecedores de:</Label>
                                     <div className="grid grid-cols-2 gap-2">
                                        {supplierCategories.map(category => (
                                            <div key={category} className="flex items-center space-x-2">
                                                <Checkbox
                                                    id={category}
                                                    checked={targetCategories.includes(category)}
                                                    onCheckedChange={() => handleCategoryChange(category)}
                                                />
                                                <label htmlFor={category} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                                    {category}
                                                </label>
                                            </div>
                                        ))}
                                     </div>
                                </div>
                            </div>
                            <SheetFooter className="pt-4 mt-auto">
                                <SheetClose asChild>
                                    <Button type="button" variant="outline">Cancelar</Button>
                                </SheetClose>
                                <Button type="submit" disabled={isSubmitting}>
                                    {isSubmitting ? <><Loader className="mr-2 animate-spin" /> Enviando...</> : 'Enviar Pedido'}
                                </Button>
                            </SheetFooter>
                        </form>
                    </SheetContent>
                </Sheet>
            </div>

            {isLoading ? (
                <div className="text-center py-10">
                    <Loader className="mx-auto h-8 w-8 animate-spin text-primary" />
                    <p className="mt-4 text-muted-foreground">Carregando seus orçamentos...</p>
                </div>
            ) : quotes.length === 0 ? (
                <Card className="text-center py-10 border-dashed">
                    <CardHeader>
                        <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
                        <CardTitle>Nenhum pedido de orçamento criado</CardTitle>
                        <CardDescription>Crie seu primeiro pedido para receber cotações de fornecedores.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={() => setIsSheetOpen(true)}>
                            <PlusCircle className="mr-2"/>
                            Criar Primeiro Pedido
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-4">
                    {quotes.map((quote) => (
                        <Card key={quote.id} className="hover:shadow-md transition-shadow">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-xl">{quote.title}</CardTitle>
                                        <CardDescription className="pt-1">
                                            Enviado em: {quote.createdAt ? format(quote.createdAt.toDate(), "dd 'de' MMMM, yyyy", { locale: ptBR }) : '...'}
                                        </CardDescription>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant={quote.status === 'open' ? 'default' : 'secondary'}>{quote.status === 'open' ? 'Aberto' : 'Fechado'}</Badge>
                                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => openDeleteDialog(quote.id)}>
                                            <Trash2 className="h-5 w-5" />
                                            <span className="sr-only">Excluir</span>
                                        </Button>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm font-medium">Itens:</p>
                                <ul className="list-disc list-inside text-muted-foreground text-sm">
                                    {quote.items.map((item, index) => (
                                        <li key={index}>{item.quantity} {item.unit} de {item.name}</li>
                                    ))}
                                </ul>
                            </CardContent>
                             <CardFooter>
                                <Button variant="outline">Ver Respostas (0)</Button>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            )}
            
            <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                    <AlertDialogDescription>
                        Esta ação não pode ser desfeita. Isso excluirá permanentemente o seu pedido de orçamento.
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel onClick={() => setShowDeleteAlert(false)}>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={() => handleDeleteQuote(quoteToDelete)} className="bg-destructive hover:bg-destructive/90">
                        Excluir
                    </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
}
